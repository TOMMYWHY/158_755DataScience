# create-movie_recommendation_system-from-0
use mysql python create a GUI movie recommendation system
